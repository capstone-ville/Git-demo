<#
.SYNOPSIS
    Provisions the SharePoint lists for the Kudos Wall.

.DESCRIPTION
    Creates two lists on an existing SharePoint site:

      Kudos Submissions  - every submission from the Power App. Item-level security:
                           people can only see and edit their own submissions.
      Wall of Fame       - approved kudos only, written by the approval flow.
                           Read-only for site members; this is what the wall shows.

    Splitting the two means a submitter can never publish their own kudos by editing
    the Status column, and rejected submissions are never visible to other employees.

    The script is safe to re-run: existing lists and columns are left as they are.

.PARAMETER SiteUrl
    The SharePoint site, e.g. https://contoso.sharepoint.com/sites/recognition

.PARAMETER ClientId
    Client ID of the Entra ID app registration used by PnP.PowerShell
    (see https://pnp.github.io/powershell/articles/registerapplication.html).

.PARAMETER Principles
    The thank-you categories offered in the app. Edit later in the list settings
    (Kudos Submissions > Principle column) - the app reads them from there.

.PARAMETER GrantEveryone
    Also gives "Everyone except external users" Contribute on Kudos Submissions and
    Read on Wall of Fame, so the whole organisation can use the app without being
    added to the site. Leave it off if you manage access through site groups.

.EXAMPLE
    ./Provision-KudosWall.ps1 -SiteUrl https://contoso.sharepoint.com/sites/recognition `
                              -ClientId 00000000-0000-0000-0000-000000000000 -GrantEveryone

.NOTES
    Requires PowerShell 7.4+ and PnP.PowerShell 2.x or later:
        Install-Module PnP.PowerShell -Scope CurrentUser
    You need Owner rights on the site. Role names ("Read", "Edit", "Contribute")
    assume an English-language site.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string]   $SiteUrl,
    [Parameter(Mandatory)] [string]   $ClientId,
    [string[]] $Principles = @("Customer focus", "Teamwork", "Ownership", "Innovation", "Integrity", "Going the extra mile"),
    [switch]   $GrantEveryone
)

$ErrorActionPreference = "Stop"

Connect-PnPOnline -Url $SiteUrl -ClientId $ClientId -Interactive

# ---------------------------------------------------------------- helpers
function Get-OrCreateList([string]$Title, [string]$UrlName) {
    $list = Get-PnPList -Identity $Title -ErrorAction SilentlyContinue
    if ($null -eq $list) {
        Write-Host "Creating list '$Title'" -ForegroundColor Cyan
        $list = New-PnPList -Title $Title -Url "Lists/$UrlName" -Template GenericList -OnQuickLaunch
    } else {
        Write-Host "List '$Title' already exists - reusing it" -ForegroundColor Yellow
    }
    return $list
}

function Add-FieldIfMissing($List, [string]$InternalName, [string]$FieldXml) {
    $existing = Get-PnPField -List $List -Identity $InternalName -ErrorAction SilentlyContinue
    if ($null -eq $existing) {
        Add-PnPFieldFromXml -List $List -FieldXml $FieldXml | Out-Null
        Write-Host "  + $InternalName"
    } else {
        Write-Host "  = $InternalName (exists)"
    }
}

function Get-ChoiceXml([string[]]$Values) {
    ($Values | ForEach-Object { "<CHOICE>$([System.Security.SecurityElement]::Escape($_))</CHOICE>" }) -join ""
}

$principleChoices = Get-ChoiceXml $Principles

# ---------------------------------------------------------------- Kudos Submissions
$sub = Get-OrCreateList -Title "Kudos Submissions" -UrlName "KudosSubmissions"

# Title is kept as the internal name but shown as "Recognition Headline"
Set-PnPField -List $sub -Identity "Title" -Values @{ Title = "Recognition Headline" } | Out-Null

$subFields = [ordered]@{
    "Recipient"          = '<Field Type="User" Name="Recipient" StaticName="Recipient" DisplayName="Recipient" UserSelectionMode="PeopleOnly" />'
    "RecipientManager"   = '<Field Type="User" Name="RecipientManager" StaticName="RecipientManager" DisplayName="Recipient Manager" UserSelectionMode="PeopleOnly" />'
    "ManagerSource"      = '<Field Type="Choice" Name="ManagerSource" StaticName="ManagerSource" DisplayName="Manager Source" Format="Dropdown"><Default>Entra ID</Default><CHOICES><CHOICE>Entra ID</CHOICE><CHOICE>Override</CHOICE></CHOICES></Field>'
    "Principle"          = "<Field Type=""Choice"" Name=""Principle"" StaticName=""Principle"" DisplayName=""Principle"" Format=""Dropdown""><CHOICES>$principleChoices</CHOICES></Field>"
    "RecognitionMessage" = '<Field Type="Note" Name="RecognitionMessage" StaticName="RecognitionMessage" DisplayName="Recognition Message" RichText="FALSE" NumLines="8" />'
    "Sender"             = '<Field Type="User" Name="Sender" StaticName="Sender" DisplayName="Sender" UserSelectionMode="PeopleOnly" />'
    "SubmissionDate"     = '<Field Type="DateTime" Name="SubmissionDate" StaticName="SubmissionDate" DisplayName="Submission Date" Format="DateTime" />'
    "Status"             = '<Field Type="Choice" Name="Status" StaticName="Status" DisplayName="Status" Format="Dropdown"><Default>Pending</Default><CHOICES><CHOICE>Pending</CHOICE><CHOICE>Approved</CHOICE><CHOICE>Rejected</CHOICE></CHOICES></Field>'
    "Reviewer"           = '<Field Type="User" Name="Reviewer" StaticName="Reviewer" DisplayName="Reviewer" UserSelectionMode="PeopleOnly" />'
    "ReviewerComment"    = '<Field Type="Note" Name="ReviewerComment" StaticName="ReviewerComment" DisplayName="Reviewer Comment" RichText="FALSE" NumLines="4" />'
    "PublishDate"        = '<Field Type="DateTime" Name="PublishDate" StaticName="PublishDate" DisplayName="Publish Date" Format="DateTime" />'
    "ManagerReply"       = '<Field Type="Note" Name="ManagerReply" StaticName="ManagerReply" DisplayName="Manager Reply" RichText="FALSE" NumLines="4" />'
}
Write-Host "Columns on Kudos Submissions:"
foreach ($k in $subFields.Keys) { Add-FieldIfMissing -List $sub -InternalName $k -FieldXml $subFields[$k] }

# Views
$subViewFields = @("LinkTitle", "Recipient", "Principle", "Sender", "SubmissionDate", "Status", "Reviewer", "PublishDate")
Set-PnPView -List $sub -Identity "All Items" -Fields $subViewFields | Out-Null

if (-not (Get-PnPView -List $sub -Identity "Pending review" -ErrorAction SilentlyContinue)) {
    Add-PnPView -List $sub -Title "Pending review" -Fields @("LinkTitle", "Recipient", "RecipientManager", "ManagerSource", "Principle", "Sender", "SubmissionDate") `
        -Query "<Where><Eq><FieldRef Name='Status'/><Value Type='Choice'>Pending</Value></Eq></Where><OrderBy><FieldRef Name='SubmissionDate' Ascending='TRUE'/></OrderBy>" | Out-Null
}

# Item-level security: read and edit only your own submissions.
# (Site owners and the account that owns the flow connection still see everything.)
Set-PnPList -Identity $sub -ReadSecurity AllUsersReadAccessOnItemsTheyCreate -WriteSecurity WriteOnlyMyItems | Out-Null
Set-PnPList -Identity $sub -EnableVersioning $true | Out-Null

# ---------------------------------------------------------------- Wall of Fame
$wall = Get-OrCreateList -Title "Wall of Fame" -UrlName "WallOfFame"
Set-PnPField -List $wall -Identity "Title" -Values @{ Title = "Recognition Headline" } | Out-Null

$wallFields = [ordered]@{
    "Recipient"        = '<Field Type="User" Name="Recipient" StaticName="Recipient" DisplayName="Recipient" UserSelectionMode="PeopleOnly" />'
    "Principle"        = '<Field Type="Text" Name="Principle" StaticName="Principle" DisplayName="Principle" MaxLength="255" />'
    "ShortDescription" = '<Field Type="Note" Name="ShortDescription" StaticName="ShortDescription" DisplayName="Short Description" RichText="FALSE" NumLines="3" />'
    # Full note, shown when someone opens a kudos on the wall. Remove this line (and the
    # matching flow field) if full notes should only go to the recipient and manager by email.
    "RecognitionMessage" = '<Field Type="Note" Name="RecognitionMessage" StaticName="RecognitionMessage" DisplayName="Recognition Message" RichText="FALSE" NumLines="8" />'
    "Sender"         = '<Field Type="User" Name="Sender" StaticName="Sender" DisplayName="Sender" UserSelectionMode="PeopleOnly" />'
    "PublishDate"      = '<Field Type="DateTime" Name="PublishDate" StaticName="PublishDate" DisplayName="Publish Date" Format="DateTime" />'
    "SubmissionId"     = '<Field Type="Number" Name="SubmissionId" StaticName="SubmissionId" DisplayName="Submission ID" Decimals="0" />'
}
Write-Host "Columns on Wall of Fame:"
foreach ($k in $wallFields.Keys) { Add-FieldIfMissing -List $wall -InternalName $k -FieldXml $wallFields[$k] }

# Default view: newest first, rendered as cards
Set-PnPView -List $wall -Identity "All Items" -Fields @("LinkTitle", "Recipient", "Principle", "ShortDescription", "Sender", "PublishDate") `
    -Values @{ ViewQuery = "<OrderBy><FieldRef Name='PublishDate' Ascending='FALSE'/></OrderBy>" } | Out-Null

$formatPath = Join-Path $PSScriptRoot "wall-card-format.json"
if (Test-Path $formatPath) {
    try {
        $json = Get-Content $formatPath -Raw
        Set-PnPView -List $wall -Identity "All Items" -Values @{ CustomFormatter = $json } | Out-Null
        Write-Host "Applied card formatting to Wall of Fame view"
    } catch {
        Write-Warning "Couldn't apply view formatting automatically. Open the list > All Items > Format current view > Advanced mode, and paste wall-card-format.json."
    }
}

# Wall of Fame is read-only for members; only owners and the flow account write to it
try {
    Set-PnPList -Identity $wall -BreakRoleInheritance -CopyRoleAssignments | Out-Null
    $members = Get-PnPGroup -AssociatedMemberGroup
    Set-PnPListPermission -Identity $wall -Group $members -AddRole "Read" -RemoveRole "Edit" | Out-Null
    Write-Host "Wall of Fame: members set to Read"
} catch {
    Write-Warning "Couldn't adjust Wall of Fame permissions: $($_.Exception.Message). Set members to Read manually."
}

# ---------------------------------------------------------------- optional: open to everyone
if ($GrantEveryone) {
    try {
        $tenantId = Get-PnPTenantId
        $everyone = "c:0-.f|rolemanager|spo-grid-all-users/$tenantId"
        Set-PnPList -Identity $sub -BreakRoleInheritance -CopyRoleAssignments | Out-Null
        Set-PnPListPermission -Identity $sub  -User $everyone -AddRole "Contribute" | Out-Null
        Set-PnPListPermission -Identity $wall -User $everyone -AddRole "Read" | Out-Null
        Write-Host "Granted Everyone except external users: Contribute on submissions, Read on wall"
    } catch {
        Write-Warning "Couldn't grant org-wide access: $($_.Exception.Message)"
    }
}

Write-Host ""
Write-Host "Done. Lists ready on $SiteUrl" -ForegroundColor Green
Write-Host "Next: import the flow (03-powerautomate) and point it at these two lists."
