# Kudos Wall – starter kit

Power Apps + SharePoint + Power Automate. An employee picks a colleague, the colleague's
manager is fetched from Entra ID (with an override if it's wrong), they choose a principle and
write a note. A small review group approves or rejects it. Approved kudos go on the Wall of Fame
and the full note is emailed to the recipient with their manager in copy. Rejected ones go back
to the submitter with the reviewer's comment.

```
Power App ──Patch──▶ Kudos Submissions ──trigger──▶ Flow ──▶ Approval (review group)
                     (own items only)                         │
                                         Approve ◀────────────┴────────────▶ Reject
                                            │                                   │
                     Status=Approved, Reviewer, Publish Date     Status=Rejected, Reviewer, comment
                     + new item in Wall of Fame (read-only)      + email to submitter
                     + email to recipient, Cc manager
```

## What's in the kit

| Folder | File | What it is |
|---|---|---|
| 01-sharepoint | `Provision-KudosWall.ps1` | Creates both lists, columns, views and permissions (PnP.PowerShell) |
| | `wall-card-format.json` | Card-style view formatting for the Wall of Fame list (the script applies it) |
| 02-powerapps | `App.Formulas.txt` | Named formulas: signed-in user, theme colours, form rules |
| | `scrWall.pa.yaml`, `scrSubmit.pa.yaml` | The two screens, ready to paste into Power Apps Studio |
| | `*.controls.yaml` | Fallback: the same screens as a control block, if a screen paste is rejected |
| 03-powerautomate | `KudosWall-ApprovalFlow.zip` | Importable flow package |
| | `flow-definition.json` | The same flow in readable form, for reference or rebuilding |

## Why two lists

Your outline had one list with a Status column. The kit splits it in two:

- **Kudos Submissions** – everything submitted. Item-level security means people only see and edit their own submissions, so rejected kudos stay private.
- **Wall of Fame** – only approved items, written by the flow. Members can read but not edit.

With a single list, anyone who can create items can also edit their own Status to "Approved" in the SharePoint UI and publish themselves. Here, editing your own submission does nothing – only the flow writes to the wall.

## Setup, in order

### 1. SharePoint lists
1. Install PnP.PowerShell (`Install-Module PnP.PowerShell -Scope CurrentUser`, PowerShell 7.4+). Recent versions need your own Entra ID app registration for sign-in; if your IT team already has one for PnP, use its client ID.
2. Run:
   ```powershell
   ./Provision-KudosWall.ps1 -SiteUrl https://<tenant>.sharepoint.com/sites/<site> -ClientId <app-id> -GrantEveryone
   ```
   Pass your own categories with `-Principles "Teamwork","Ownership",...` – or edit the Principle column choices later; the app reads them live.
   Drop `-GrantEveryone` if you control access through the site's groups instead.
3. On the SharePoint page that should host the wall, add a **List** web part pointing to *Wall of Fame*. The card formatting comes with the view.

If you'd rather adapt your existing list than create new ones, match the internal names in the column table below – the app and flow use internal names.

### 2. Power Automate flow
1. Power Automate › My flows › **Import › Import Package (Legacy)** › upload `KudosWall-ApprovalFlow.zip`.
2. For each of the three connections (SharePoint, Approvals, Office 365 Outlook) choose **Select during import** and pick your connection. Import.
3. Open the flow and edit:
   - **Trigger** – re-select your site address and the *Kudos Submissions* list.
   - **Initialize ApproverEmails** – your review group, semicolon-separated (Approvals needs individual addresses, not a group mailbox).
   - **Initialize AppUrl** – the app's web link (fill this in after step 3: Power Apps › the app › Details › Web link). It powers the *See it on the Wall of Fame* button in the email, which opens the app straight onto that kudos.
   - **Update submission (both branches)** and **Create Wall of Fame item** – re-select site and list.
4. Save and turn on.

The flow owner's account writes to both lists, so it must be a site owner (or have Full Control on the lists) – ideally a service account so the flow survives people leaving.

### 3. Power App
1. Create a **blank canvas app** (tablet or phone layout – the screens adapt to width).
2. Add data: *Kudos Submissions*, *Wall of Fame* (SharePoint), and *Office 365 Users*.
3. Tree view › **App** › **Formulas** › paste `App.Formulas.txt`.
4. Paste the screens: open `scrWall.pa.yaml`, copy all, right-click in the Tree view › **Paste code**. Repeat for `scrSubmit.pa.yaml`. Delete the default Screen1 and make sure scrWall is first.
   - If Studio won't paste a whole screen, add a blank screen with the same name, then right-click it › **Paste code** with the matching `*.controls.yaml`.
5. Settings › General › **Data row limit** › 2000 (the wall loads the newest items into memory for fast filtering and stats).
6. If your principles differ from the defaults, edit `nfPrincipleStyles` in App.Formulas – one row per principle with its colour and emoji.
7. Save, publish and share the app with the people who should use it.
8. To make the SharePoint page *be* the wall, add a **Power Apps** web part to the page and point it at the app. The list web part on *Wall of Fame* still works as a plain fallback.

## The wall experience

- **Hero banner** – gradient header with "kudos this month" and "people recognised" counters, and a *Give kudos* button.
- **"For you" spotlight** – a gold banner for anyone who has been recognised, with their count and the latest headline.
- **Welcome moment** – if you were thanked in the last 7 days, the app opens with that kudos already on screen, a "Thank you, *first name*! 🎉" greeting and a confetti burst. This happens once per app session.
- **Cards** – responsive grid (1–3 columns by screen width). Each card has a colour stripe and chip per principle, the recipient's photo (or initials), the headline, a short preview, a NEW badge for the last 3 days, and a gold border plus FOR YOU badge on your own kudos.
- **Tabs, search, filter** – All / For me / Sent by me, search by recipient or sender name, filter by principle.
- **Detail view** – tap any card to open it: principle-coloured header, large avatar, the full thank-you note, sender and date. Recipients get confetti and a *Thank them back* button. Everyone else gets *Add your kudos* for that person. Either button opens the form with the person already filled in.
- **Email deep link** – the approval email links straight to the kudos in the app, so the first thing the recipient sees is their celebration.

The detail view shows the **full note to everyone who can open the wall**, because the flow now copies it to *Wall of Fame*. If full notes should stay between the recipient and their manager, delete the *RecognitionMessage* line from the Wall of Fame section of the script and the `item/RecognitionMessage` field from *Create Wall of Fame item*. The detail view then falls back to the short description.

## Columns

**Kudos Submissions**

| Display name | Internal name | Type | Set by |
|---|---|---|---|
| Recognition Headline | Title | Text | App |
| Recipient | Recipient | Person | App |
| Recipient Manager | RecipientManager | Person | App (Entra ID or override) |
| Manager Source | ManagerSource | Choice: Entra ID / Override | App |
| Principle | Principle | Choice | App |
| Recognition Message | RecognitionMessage | Multi-line plain text | App |
| Sender | Sender | Person | App |
| Submission Date | SubmissionDate | Date & time | App |
| Status | Status | Choice: Pending / Approved / Rejected | App → flow |
| Reviewer | Reviewer | Person | Flow |
| Reviewer Comment | ReviewerComment | Multi-line plain text | Flow |
| Publish Date | PublishDate | Date & time | Flow |
| Manager Reply | ManagerReply | Multi-line plain text | Not wired yet |

*Item Type* and *Path* from your outline are built-in SharePoint columns, so they aren't created. "Application Status" looked like a duplicate of Status, so it's folded into that one column.

**Wall of Fame**: Title, Recipient, Principle (text), ShortDescription (first ~220 characters of the note), RecognitionMessage (full note, for the detail view), Sender, PublishDate, SubmissionId (links back to the submission).

Already ran the script for v1? Run it again – it only adds the missing column.

## Things to check on first run

- Submit a kudos to a colleague with a manager in Entra ID, and one where you tick the override – check Manager Source.
- Approve from Teams (Approvals app) or the email – the item should appear on the wall within a minute or two, and the email should arrive with the manager in Cc.
- Reject with a comment – the submitter should get it.
- Sign in as a non-owner and confirm you can't see other people's submissions or edit the wall.

## Known limits and easy next steps

- The import package is hand-built against the legacy export format. If the import is refused, create a new automated flow from `flow-definition.json` – it lists every action, parameter and expression to copy across.
- The flow polls the list every minute; approvals time out after 30 days by default.
- Recipient search uses Office 365 Users, which only returns enabled accounts with a mailbox.
- Profile photos load per card. That's fine for a few hundred kudos; past that, consider paging the wall.
- The confetti is an animated SVG. It plays in the browser and the Teams/desktop players. If a player shows it static, nothing breaks – the pieces just appear frozen in the header.
- Ideas for v2: a Teams post to a channel on approval, a "Manager Reply" step, a Power BI page over Kudos Submissions (who recognises whom, by principle and org unit).
